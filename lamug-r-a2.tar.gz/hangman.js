/**
 * @file hangman.js     Implementation of Hangman 
 * 
 *
 * @brief
 *    Implementation of Hangman game in Javascript code
 *
 * @author Rodolfo Lamug
 * @date 2019
 */

"use strict";

// Global Variables
var random_word = ""; // random word being guessed
var blanks = []; // blanks array
var incorrect_guess = 0; // counts number of incorrect guesses
var lives = 6;  // number of lives given
var current_lives = 6; // keeps count of player's current lives 
var game_over = 1; // checks if game is over or not
var guessed_letters = []; //array of guessed letters
var score = 0;  // keeps count of player's score

/*
 * draw() function
 * @description Draws the hangman everytime the user guesses incorrectly
 */
function draw() {
  // No incorrect guesses
  if (incorrect_guess == 0) {
    document.getElementById("hangman").src = "hang1.PNG";
  }
  // 1 incorrect guesses
  else if (incorrect_guess == 1) {
    document.getElementById("hangman").src = "hang2.PNG";
  }
  // 2 incorrect guesses
  else if (incorrect_guess == 2) {
    document.getElementById("hangman").src = "hang3.PNG";
  }
  // 3 incorrect guesses
  else if (incorrect_guess == 3) {
    document.getElementById("hangman").src = "hang4.PNG";
  }
  // 4 incorrect guesses
  else if (incorrect_guess == 4) {
    document.getElementById("hangman").src = "hang5.PNG";
  }
  // 5 incorrect guesses
  else if (incorrect_guess == 5) {
    document.getElementById("hangman").src = "hang6.PNG";
  }
  // 6 incorrect guesses
  else {
    document.getElementById("hangman").src = "hang7.PNG";
  }
}

/* 
 * new_game() function
 * @description Starts a new hangman game resets all the global variables
 */
function new_game() {
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
      // Reset everything when starting a new game
      random_word = "";
      blanks = [];
      incorrect_guess = 0;
      current_lives = 6;
      game_over = 0;
      guessed_letters = [];
      document.getElementById("instructions").innerHTML 
        = "Just enter letters to guess!";
      document.getElementById("winOrLose").innerHTML = "";
      document.getElementById("guessWord").innerHTML = "";
      document.getElementById("hangman").src = "hang1.PNG";
      document.getElementById("lives").innerHTML = "Lives: 6";
      document.getElementById("score").innerHTML = "Score: " + score;
      document.getElementById("guessedLetters").innerHTML = guessed_letters;

      // Gets random word to guess using Datamuse API
      let text = this.responseText;
      let response = JSON.parse(text); //an array
      let random_number = Math.floor(Math.random() * (response.length + 1))
      random_word = response[random_number].word; //random word being guessed
      console.log(random_word);

      // Underlined blanks for the word being guessed
      for (var i = 0; i < random_word.length; i++) {
        blanks[i] = "_";
      }
      document.getElementById("blanks").innerHTML = blanks.join(" ");
    }
  };

  xhttp.open("GET", "https://api.datamuse.com/words?ml=deadly", true);
  xhttp.send();
}

/* 
 * guessLetter() function
 * @description Handles guessing of letters in the hangman game
 */
function guessLetter(event) {
  if (current_lives > 0 && game_over == 0) {
    let letter = String.fromCharCode(event.which); // Letter being guessed
    var correct = 0; // Set to 1 if correct letter is guessed
    var correct_letter_count = 0;

    // Iterate through random_word
    for (var j = 0; j < random_word.length; j++) {
      // Correct letter guessed at index of array
      if (random_word[j] === letter) {
        blanks[j] = letter;
        document.getElementById("blanks").innerHTML = blanks.join(" ");
        correct = 1;
      }
      // Keep count of correct letters
      if (blanks[j] !== "_") {
        correct_letter_count += 1;
      }
    }

    // Word is complete, Player wins
    if (correct_letter_count === random_word.length) {
      document.getElementById("winOrLose").innerHTML 
        = "Congratulations! You Win!!!";
      game_over = 1;
      score += 1;
      document.getElementById("score").innerHTML = "Score: " + score;
    }

    // Incorrect letter guess draw hangman and put letter in guessed_letters
    if (correct != 1) {
      incorrect_guess += 1;
      current_lives -= 1;
      document.getElementById("lives").innerHTML = "Lives: " + current_lives;
      draw();
      guessed_letters.push(letter);
      document.getElementById("guessedLetters").innerHTML = guessed_letters;
    }

    // Check if player has run out of lives
    if (incorrect_guess == lives) {
      document.getElementById("winOrLose").innerHTML 
        = "You have run out of lives. You Lose...";
    }
  }
}

/* 
 * guessWord() function
 * @description Handles guessing of words in the Hangman game
 */
function guessWord() {
  if (current_lives > 0 && game_over == 0) {

    var guess = prompt("Please enter your word guess.");
    // Player cancelled prompt
    if (guess == null || guess == "") {
      document.getElementById("guessWord").innerHTML 
        = "Player cancelled word guess";
    }
    // Player guessed correctly
    else if (guess === random_word) {
      document.getElementById("guessWord").innerHTML 
        = "Correct guess! Your guess was: " + guess;
      document.getElementById("winOrLose").innerHTML
        = "Congratulations! You Win!!!";
      game_over = 1;
      score += 1;
      document.getElementById("score").innerHTML = "Score: " + score;
    }
    // Incorrect guess
    else {
      document.getElementById("guessWord").innerHTML 
        = "Incorrect word guess. Your guess was : " + guess;
      incorrect_guess += 1;
      current_lives -= 1;
      document.getElementById("lives").innerHTML = "Lives: " + current_lives;
      draw();
    }

    // Check if player has run out of lives
    if (incorrect_guess == lives) {
      document.getElementById("winOrLose").innerHTML 
        = "You have run out of lives. You Lose...";
      game_over = 1;
    }
  }
}
